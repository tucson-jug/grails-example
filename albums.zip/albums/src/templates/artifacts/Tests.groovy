@artifact.package@class @artifact.name@ extends GroovyTestCase {

    void testSomething() {

    }
}
