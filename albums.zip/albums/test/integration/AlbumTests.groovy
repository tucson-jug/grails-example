class AlbumTests extends GroovyTestCase {

    void testSomething() {

    }
}
