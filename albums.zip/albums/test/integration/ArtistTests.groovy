class ArtistTests extends GroovyTestCase {

    void testSomething() {

    }
}
